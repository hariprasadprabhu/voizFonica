import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {AddUserService} from '../add-user.service';
import { User } from '../user';


@Component({
  selector: 'app-admin-prepaid-customer',
  templateUrl: './admin-prepaid-customer.component.html',
  styleUrls: ['./admin-prepaid-customer.component.css']
})
export class AdminPrepaidCustomerComponent implements OnInit {
  customers : Observable<User[]>;
  constructor(private service:AddUserService) { }

  ngOnInit(): void 
  {
    this.initialize();
  }

  initialize()
  {
    
    this.customers=this.service.displayPrepaid();
   
  }
}
