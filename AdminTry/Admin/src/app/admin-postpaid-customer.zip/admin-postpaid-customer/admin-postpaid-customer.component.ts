import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {AddUserService} from '../add-user.service';
import { User } from '../user';

@Component({
  selector: 'app-admin-postpaid-customer',
  templateUrl: './admin-postpaid-customer.component.html',
  styleUrls: ['./admin-postpaid-customer.component.css']
})
export class AdminPostpaidCustomerComponent implements OnInit {
  customers : Observable<User[]>;
  constructor(private service:AddUserService) { }

  ngOnInit(): void 
  {
    this.initialize();
  }

  initialize()
  {
    
    this.customers=this.service.displayPostpaid();
   
  }

}
