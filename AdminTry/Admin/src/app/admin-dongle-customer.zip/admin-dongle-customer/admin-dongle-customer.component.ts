import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {AddUserService} from '../add-user.service';
import { User } from '../user';

@Component({
  selector: 'app-admin-dongle-customer',
  templateUrl: './admin-dongle-customer.component.html',
  styleUrls: ['./admin-dongle-customer.component.css']
})
export class AdminDongleCustomerComponent implements OnInit {
  customers : Observable<User[]>;
  constructor(private service:AddUserService) { }

  ngOnInit(): void 
  {
    this.initialize();
  }

  initialize()
  {
    
    this.customers=this.service.displayDongle();
   
  }

}
