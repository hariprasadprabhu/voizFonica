import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Customer} from './customer';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http:HttpClient) {
  }
  loginCustomerFromRemote(cust:Customer):Observable<any>
  {
   return  this._http.post<any>("http://localhost:8081/login",cust);
  }
}
