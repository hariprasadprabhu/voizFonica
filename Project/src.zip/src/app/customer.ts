import { LoginComponent } from './login/login.component';

export class Customer {
    id:number;
    phoneNum:number;
    userName:string;
    emailId:string;
    password:string;
    // constructor(id:number,phoneNum:number,userName:string,emailId:string,password:string)
    // {
    //     this.id=id;
    //     this.phoneNum=phoneNum;
    //     this.userName=userName;
    //     this.emailId=emailId;
    //     this.password=password;
    // }
    constructor()
    {
        
    }
}
