import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-prepaid',
  templateUrl: './home-prepaid.component.html',
  styleUrls: ['./home-prepaid.component.css']
})
export class HomePrepaidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
